package com.example.dlmsconfigurator.core.dlms

import com.example.dlmsconfigurator.core.data.ConnectionParams
import com.example.dlmsconfigurator.core.data.OperationItem
import com.example.dlmsconfigurator.core.transport.DlmsTransport
import gurux.dlms.GXByteBuffer
import gurux.dlms.GXDLMSClient
import gurux.dlms.secure.GXDLMSSecureClient
import gurux.dlms.GXReplyData
import gurux.dlms.GXDateTime
import gurux.dlms.enums.Authentication
import gurux.dlms.enums.DataType
import gurux.dlms.enums.InterfaceType
import gurux.dlms.enums.ObjectType
import gurux.dlms.enums.Security
import gurux.dlms.objects.GXDLMSObject
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DlmsEngine(
    private val connectionParams: ConnectionParams,
    private val transport: DlmsTransport
) {
    private val client = GXDLMSSecureClient()

    init {
        client.apply {
            useLogicalNameReferencing = true
            interfaceType = when (connectionParams.interfaceType.uppercase()) {
                "HDLC" -> InterfaceType.HDLC
                else -> InterfaceType.HDLC
            }
            clientAddress = connectionParams.clientAddress
            serverAddress = connectionParams.serverAddress

            connectionParams.systemTitle?.let {
                ciphering.systemTitle = hexToBytes(it)
            }
            connectionParams.authenticationKey?.let {
                ciphering.authenticationKey = hexToBytes(it)
            }
            (connectionParams.blockCipherKey ?: connectionParams.encryptionKey)?.let {
                ciphering.blockCipherKey = hexToBytes(it)
            }

            val pwd = connectionParams.password
            val pwdBytes = if (pwd != null && (pwd.startsWith("0x") || pwd.startsWith("0X"))) {
                hexToBytes(pwd)
            } else {
                pwd?.toByteArray(Charsets.US_ASCII)
            }

            when (connectionParams.security.lowercase()) {
                "none" -> {
                    authentication = Authentication.NONE
                    ciphering.security = Security.NONE
                }
                "low" -> {
                    authentication = Authentication.LOW
                    password = pwdBytes
                    ciphering.security = Security.NONE
                }
                "high" -> {
                    authentication = Authentication.HIGH
                    password = pwdBytes
                    ciphering.security = Security.NONE
                }
                "authenticationencryption", "high_auth_enc" -> {
                    authentication = Authentication.HIGH
                    password = pwdBytes
                    ciphering.security = Security.AUTHENTICATION_ENCRYPTION
                }
            }

            if (connectionParams.ciphering) {
                ciphering.security = Security.AUTHENTICATION_ENCRYPTION
            }
        }
    }

    private var isAssociated = false

    private fun hexToBytes(hex: String): ByteArray {
        val cleanHex = hex.removePrefix("0x").removePrefix("0X").replace(" ", "").replace(":", "")
        if (cleanHex.isEmpty()) return ByteArray(0)
        val result = ByteArray(cleanHex.length / 2)
        for (i in 0 until cleanHex.length step 2) {
            result[i / 2] = cleanHex.substring(i, i + 2).toInt(16).toByte()
        }
        return result
    }

    private fun readInvocationCounter(): Long {
        val tempClient = GXDLMSSecureClient().apply {
            useLogicalNameReferencing = true
            interfaceType = client.interfaceType
            clientAddress = client.clientAddress
            serverAddress = client.serverAddress
            authentication = Authentication.NONE
            ciphering.security = Security.NONE
        }

        val reply = GXReplyData()

        // 1. SNRM (only if HDLC)
        if (tempClient.interfaceType == InterfaceType.HDLC) {
            val snrm = tempClient.snrmRequest()
            if (snrm != null) {
                readDLMSPacket(tempClient, snrm, reply)
                tempClient.parseUAResponse(reply.data)
            }
        }

        // 2. AARQ
        val aarqPackets = tempClient.aarqRequest()
        for (packet in aarqPackets) {
            reply.clear()
            readDLMSPacket(tempClient, packet, reply)
        }
        tempClient.parseAareResponse(reply.data)

        // 3. Read Invocation Counter
        val obis = connectionParams.invocationCounterObis ?: "0.0.43.1.0.255"
        val dataObj = createCosemObject(1, obis)
        val readPackets = tempClient.read(dataObj, 2)
        val readReply = GXReplyData()
        readDataBlock(tempClient, readPackets, readReply)
        tempClient.updateValue(dataObj, 2, readReply.value)

        // 4. Disconnect
        try {
            val disc = tempClient.disconnectRequest()
            if (disc != null) {
                val discReply = GXReplyData()
                readDLMSPacket(tempClient, disc, discReply)
            }
        } catch (ignored: Exception) {}

        val counterVal = readReply.value
        return when (counterVal) {
            is Number -> counterVal.toLong()
            else -> throw IOException("Invocation counter read returned non-numeric value: $counterVal")
        }
    }

    fun associate() {
        if (!transport.isOpen()) {
            transport.open()
        }

        if (connectionParams.ciphering) {
            try {
                val counterVal = readInvocationCounter()
                client.ciphering.invocationCounter = counterVal + 1
            } catch (e: Exception) {
                throw IOException("Failed to synchronize invocation counter unauthenticated: ${e.message}", e)
            }
        }

        val reply = GXReplyData()

        // 1. SNRM Request (only for HDLC interface type)
        if (client.interfaceType == InterfaceType.HDLC) {
            val snrm = client.snrmRequest()
            if (snrm != null) {
                readDLMSPacket(client, snrm, reply)
                client.parseUAResponse(reply.data)
            }
        }

        // 2. AARQ Request
        val aarqPackets = client.aarqRequest()
        for (packet in aarqPackets) {
            reply.clear()
            readDLMSPacket(client, packet, reply)
        }
        client.parseAareResponse(reply.data)

        // 3. Challenge (HLS authentication)
        if (client.isAuthenticationRequired) {
            val challenge = client.applicationAssociationRequest
            for (packet in challenge) {
                reply.clear()
                readDLMSPacket(client, packet, reply)
            }
            client.parseAareResponse(reply.data)
        }

        isAssociated = true
    }

    fun disconnect() {
        if (isAssociated) {
            try {
                val reply = GXReplyData()
                val disc = client.disconnectRequest()
                if (disc != null) {
                    readDLMSPacket(client, disc, reply)
                }
            } catch (ignored: Exception) {}
            isAssociated = false
        }
        transport.close()
    }

    fun executeGet(
        op: OperationItem,
        onTrafficLogged: (requestHex: String, responseHex: String) -> Unit
    ): String {
        val attribute = op.attribute ?: 2
        val cosemObj = createCosemObject(op.classId, op.obis)
        val requestBytesList = client.read(cosemObj, attribute)
        
        val requestHex = requestBytesList.joinToString("") { bytesToHex(it) }
        val reply = GXReplyData()

        readDataBlock(client, requestBytesList, reply)

        val responseHex = bytesToHex(reply.data.data)
        onTrafficLogged(maskPasswordsInHex(requestHex), maskPasswordsInHex(responseHex))

        // Update value inside the object to let Gurux parse it
        client.updateValue(cosemObj, attribute, reply.value)
        
        val value = reply.value
        return formatValue(value)
    }

    private fun getDataTypeForValue(value: Any?): DataType {
        return when (value) {
            is Boolean -> DataType.BOOLEAN
            is Byte -> DataType.INT8
            is Short -> DataType.INT16
            is Int -> DataType.INT32
            is Long -> DataType.INT64
            is Float -> DataType.FLOAT32
            is Double -> DataType.FLOAT64
            is String -> DataType.OCTET_STRING
            is ByteArray -> DataType.OCTET_STRING
            else -> DataType.NONE
        }
    }

    fun executeSet(
        op: OperationItem,
        onTrafficLogged: (requestHex: String, responseHex: String) -> Unit
    ) {
        val attribute = op.attribute ?: 2
        val valueJson = op.value ?: throw IllegalArgumentException("Set operation must specify 'value'")
        val cosemObj = createCosemObject(op.classId, op.obis)

        val valueObj = parseJsonElementValue(valueJson, op.classId)
        val requestBytesList = client.write(
            cosemObj.logicalName,
            valueObj,
            getDataTypeForValue(valueObj),
            cosemObj.objectType,
            attribute
        )
        val requestHex = requestBytesList.joinToString("") { bytesToHex(it) }
        
        val reply = GXReplyData()
        readDataBlock(client, requestBytesList, reply)

        val responseHex = bytesToHex(reply.data.data)
        onTrafficLogged(maskPasswordsInHex(requestHex), maskPasswordsInHex(responseHex))
    }

    fun executeAction(
        op: OperationItem,
        onTrafficLogged: (requestHex: String, responseHex: String) -> Unit
    ) {
        val method = op.method ?: 1
        val paramsJson = op.params
        val cosemObj = createCosemObject(op.classId, op.obis)

        // Actions can take parameters
        val paramObj = paramsJson?.let { parseJsonElementValue(it, 0) }
        
        // Generate method request
        val requestBytesList = if (paramObj != null) {
            client.method(cosemObj, method, paramObj, gurux.dlms.enums.DataType.NONE)
        } else {
            client.method(cosemObj, method, null, gurux.dlms.enums.DataType.NONE)
        }
        
        val requestHex = requestBytesList.joinToString("") { bytesToHex(it) }
        
        val reply = GXReplyData()
        readDataBlock(client, requestBytesList, reply)

        val responseHex = bytesToHex(reply.data.data)
        onTrafficLogged(maskPasswordsInHex(requestHex), maskPasswordsInHex(responseHex))
    }

    private fun readDLMSPacket(activeClient: GXDLMSClient, data: ByteArray, reply: GXReplyData) {
        if (!reply.streaming && data.isEmpty()) return

        reply.error = 0
        val eop: Byte? = if (activeClient.interfaceType == InterfaceType.WRAPPER) null else 0x7E.toByte()

        val rd = GXByteBuffer()
        val buffer = ByteArray(4096)
        val startTime = System.currentTimeMillis()
        val timeoutMs = 5000
        var attempt = 0
        var succeeded = false

        if (!reply.streaming) {
            transport.write(data)
        }

        val notify = GXReplyData()

        while (!succeeded) {
            val bytesRead = try {
                transport.read(buffer, 100)
            } catch (e: Exception) {
                if (System.currentTimeMillis() - startTime > timeoutMs) {
                    throw IOException("Timeout reading packet from meter", e)
                }
                0
            }

            if (bytesRead > 0) {
                rd.set(buffer, 0, bytesRead)
                if (activeClient.getData(rd, reply, notify)) {
                    succeeded = true
                }
            } else {
                if (System.currentTimeMillis() - startTime > timeoutMs) {
                    if (attempt++ >= 3) {
                        throw IOException("Failed to receive reply from the device in given time.")
                    }
                    // Retransmit
                    if (!reply.streaming) {
                        transport.write(data)
                    }
                }
                Thread.sleep(50)
            }
        }
    }

    private fun readDataBlock(activeClient: GXDLMSClient, requestList: Array<ByteArray>, reply: GXReplyData) {
        for (packet in requestList) {
            reply.clear()
            readDLMSPacket(activeClient, packet, reply)
        }

        while (reply.isMoreData) {
            val nextPacket = if (reply.isStreaming) {
                null
            } else {
                activeClient.receiverReady(reply.moreData)
            }

            if (nextPacket != null) {
                readDLMSPacket(activeClient, nextPacket, reply)
            } else {
                readDLMSPacket(activeClient, ByteArray(0), reply)
            }
        }
    }

    private fun createCosemObject(classId: Int, obisCode: String): GXDLMSObject {
        val type = ObjectType.forValue(classId)
        val obj = GXDLMSClient.createObject(type) ?: gurux.dlms.objects.GXDLMSData(obisCode)
        obj.logicalName = obisCode
        return obj
    }

    private fun parseJsonElementValue(element: JsonElement, classId: Int): Any? {
        if (element is JsonPrimitive) {
            if (element.isString) {
                val str = element.content
                // If it's class 8 (Clock), parse ISO date time
                if (classId == 8) {
                    try {
                        val date = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).parse(str)
                        if (date != null) {
                            val cal = Calendar.getInstance().apply { time = date }
                            return GXDateTime(cal)
                        }
                    } catch (ignored: Exception) {}
                }
                return str
            }
            element.longOrNull?.let { return it }
            element.doubleOrNull?.let { return it }
            element.booleanOrNull?.let { return it }
        }
        return element.toString()
    }

    private fun formatValue(value: Any?): String {
        if (value == null) return "null"
        if (value is ByteArray) {
            return bytesToHex(value)
        }
        if (value is GXDateTime) {
            val cal = value.value
            return SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(cal.time)
        }
        if (value is List<*>) {
            return value.joinToString(", ") { formatValue(it) }
        }
        return value.toString()
    }

    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun maskPasswordsInHex(hex: String): String {
        val pwd = connectionParams.password ?: return hex
        val pwdHex = if (pwd.startsWith("0x") || pwd.startsWith("0X")) {
            pwd.removePrefix("0x").removePrefix("0X")
        } else {
            bytesToHex(pwd.toByteArray(Charsets.US_ASCII))
        }
        
        if (pwdHex.length >= 4 && hex.contains(pwdHex)) {
            val mask = "*".repeat(pwdHex.length)
            return hex.replace(pwdHex, mask)
        }
        return hex
    }
}
